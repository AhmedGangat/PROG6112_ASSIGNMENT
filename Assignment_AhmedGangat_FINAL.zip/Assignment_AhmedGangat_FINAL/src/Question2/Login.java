
package Question2;

import java.util.Vector;
import javax.swing.*;

public class Login
{
    // variable initializing and assigning
    Vector<Doctor> doctorVector = new Vector<Doctor>(); // new vector
    boolean createFlag = true; 
    boolean passwordFlag = false;
    String username; 
    String password;
    String department;
    String gender;
    int age;
    String firstName;
    String lastName;
    Doctor doctor;
    public String userName;
    public String passWord;
    
    
    //username to use: ah_m 
    //PAssword to use:gangat123
    
    public void getDetails()
    {
        username = JOptionPane.showInputDialog("Please set your username"); // assigning user input to variable
        password = JOptionPane.showInputDialog("Please set your password");
        firstName = JOptionPane.showInputDialog("Please set your first name");
        lastName = JOptionPane.showInputDialog("Please set your last name");
        gender = JOptionPane.showInputDialog("Please set your gender");
        age = Integer.parseInt(JOptionPane.showInputDialog("Please set your age"));
        department = JOptionPane.showInputDialog("Please set your department");
    }
    
    
    public String registerUser() // register user if requirements are met.
    {   
        String output;
        
        if(checkUserName()) // username check
        {
            output = "Username successfully captured";
            createFlag = true;
        }
        else
        {
            output = "Username is not correctly formatted";
            createFlag = false;
        }
        
            
        if(checkPasswordComplexity()) // check password
        {
            output = output + " and Password successfully captured";
            createFlag = true;
        }
        else
        {
            output = output + " and Password is not correctly formatted";
            createFlag = false;
        }
        
        if(createFlag)
        {
            doctor = new Doctor(username,password,department,firstName,lastName, gender, age);
            doctorVector.add(doctor);
            System.out.println(doctorVector.elementAt(0).getUserName() + "\n" + doctorVector.elementAt(0).getPassword());
        }            
        
        
        return output;
    }
    
    public boolean checkUserName()  // username requirements check
    {   
        if(username.length() <= 5 && username.contains("_"))  // if statement to check username, return true or false.
        {
            userName = username; 
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean checkPasswordComplexity() // password requirements check
    {
        if(password.length() >= 8) // if statement to check password, return true or false.
        {
            for(int i = 0; i < password.length(); i++)
            {
                if(Character.isUpperCase(password.charAt(i))) // check if password contains a uppercase letter
                {
                    passwordFlag = true;
                }
                
                if(Character.isDigit(password.charAt(i))) // check if password contains a digit
                {
                    passwordFlag = true;
                }
                
                if(!(Character.isAlphabetic(password.charAt(i)) || Character.isDigit(password.charAt(i)))) // check if password doesnt contains a digit and letter
                {
                    passwordFlag = true;
                }
            }
            
            if(passwordFlag)
            {
                passWord = password;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    public boolean LoginUser() // check user login details
    {
        username = JOptionPane.showInputDialog("Please enter your username");// recieve input from user to check against data stored
        password = JOptionPane.showInputDialog("Please enter your password");
        
        int count = 0;
        
        while(count < doctorVector.size())
        {
            System.out.println("should be finding = " + doctorVector.elementAt(0).getUserName() + "\n" + doctorVector.elementAt(0).getPassword());
            if(doctorVector.elementAt(count).getUserName().equals(username) && doctorVector.elementAt(count).getPassword().equals(password))
            {
                Main.currentDoctor = doctorVector.elementAt(count);
                //System.out.println("found = " + doctorVector.elementAt(0).getUserName() + "\n" + doctorVector.elementAt(0).getPassword());
                return true;
            }
            System.out.println("not found");
            count++;
        }
        
        return false;
    }
    
    public String returnLoginStatus() throws NoSuchMethodException, SecurityException // check if user input is correct. then output the appropriate messages
    {
        String output;
        if(LoginUser()) // check if user login is correct.
        {  
            Main.loggedIn = true;
            Home.homeScreen();
            return output = "Welcome " + doctor.getFirstName() + " " + doctor.getLastName();     
            
        }
    
        else 
        {
            return output = "Username or password incorrect, please try again.";
        }
    }
}
     
   
    

