package Question2;

public class User extends Person
{
    String username; // declare variables
    String password;
    
    public User(String uName, String pWord, String fName, String lName, String gender, int age) // user constructor
    {
        super(fName, lName, gender, age);
        username = uName; //assigning variables
        password = pWord;
    }
    
    public void setUserName(String uName)
    {
        username = uName;//assigning variable
    }
    
    public String getUserName()
    {
        return username; // return username username which was input
    }
    
    public void setPassword(String pWord)
    {
        password = pWord; //assigning variables
    }
    
    public String getPassword()
    {
        return password;// return username username which was input
    }
}
