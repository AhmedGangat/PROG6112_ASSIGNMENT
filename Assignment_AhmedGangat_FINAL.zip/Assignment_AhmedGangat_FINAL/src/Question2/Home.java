
package Question2;
import static Question2.Main.currentDoctor;
import javax.swing.*;
/**
 *
 * @author Ahmed
 */
public class Home {
    
    public static void homeScreen() //user menu accessing patient vector
    {
        String menu = JOptionPane.showInputDialog("Enter:\n1. Add patient\n2. View patient\n3. Delete patient\n4. Log out ");
        
        while(!menu.equals("5"))
        {
            switch(menu)
            {
                case "1" : //user input to add patient
                    String name = JOptionPane.showInputDialog("Please enter Patient name");
                    String surname = JOptionPane.showInputDialog("Please enter Patient surname");
                    String gender = JOptionPane.showInputDialog("Please enter Patient gender");
                    int age = Integer.parseInt(JOptionPane.showInputDialog("Please enter Patient age"));
                    String illness = JOptionPane.showInputDialog("Please enter Patient illness");
                    Patient p = new Patient(name, surname, gender, age, illness);
                    p.setDoctorID(Main.currentDoctor.getID());
                    currentDoctor.addPatient(p);        
                break;
                case "2" : // search for pt by name
                    for(int i = 0; i < Doctor.patientVector.size(); i++)
                    {
                        JOptionPane.showMessageDialog(null,Doctor.patientVector.elementAt(i).getFirstName()+"\n"+
                                                           Doctor.patientVector.elementAt(i).getLastName()+"\n"+
                                                           Doctor.patientVector.elementAt(i).getGender()+"\n"+
                                                           Doctor.patientVector.elementAt(i).getAge()+"\n"+
                                                           Doctor.patientVector.elementAt(i).getIllness());
                    }
                break;
                case "3" : // remove pt from vector
                    String ptname = JOptionPane.showInputDialog(null,"Please enter the patients name");
                    String ptSname = JOptionPane.showInputDialog(null,"Please enter the patients surname");
                     for(int i = 0; i < Doctor.patientVector.size(); i++)
                       {
                        if (Doctor.patientVector.elementAt(i).getFirstName().equalsIgnoreCase(ptname) && Doctor.patientVector.elementAt(i).getLastName().equalsIgnoreCase(ptSname))
                          {
                            Doctor.patientVector.remove(i);
                          }
                       }
                break;
                case "4" :System.exit (0); //exit
                break;
            }
            
            menu = JOptionPane.showInputDialog("Enter:\n1. Add patient\n2. View patient\n3. Delete patient\n4. Log out ");;
        }
    }
}
