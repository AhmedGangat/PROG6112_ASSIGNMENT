
package Question2;

import java.util.Vector;
import javax.swing.*;

/**
 *
 * @author Ahmed
 */
public class Doctor extends User {
    
// initialising variables    
public static String username, password, department,ID ;
public static Vector<Patient> patientVector = new Vector<Patient> (); // new vector



// creating doctor object
public Doctor (String username,String password,String department,String name,String surname,String gender, int age)
    {
       super(username, password, name, surname, gender ,age);
       
       department = JOptionPane.showInputDialog (null,"Please enter the department");
       ID= username.substring(0,3) + ((Math.random() * (100 - 1)) + 1);
    }
    
    public void setDepartment(String dept)
    {
        department = dept; //assigning variables
    }
   
    public static void addPatient(Patient p)
    {
        patientVector.add(p);
    }
    
    public int searchPatient(Patient p)
    {
        int count = 0;
        
        while(count < patientVector.size())
        {
           if(patientVector.elementAt(count).equals(p))
            {
                return count;
            }
            
            count++;
        }
        
        return -1;
    }
    
    public Patient getPatient(int index)
    {
        return patientVector.elementAt(index);
    }
    
    public static String getID()
    {
        return ID;
    }
    
} 
