
package Question2;

/**
 *
 * @author ahmed
 */
 class Person {
     
    public String name, surname, gender ; // initialising variables
    public int age ;

    public Person (String fname,String sname,String g, int a) // creating person obj
     { 
        name = fname;
        surname = sname;
        gender = g;
        age = a;
     }
    
    // getters and setters
    public void setFirstName(String fname)
    {
        name = fname; //assigning variables
    }
    
    public String getFirstName()
    {
        return name;// return username username which was input
    }
    
    public void setLastName(String sname)
    {
        surname = sname; //assigning variables
    }
    
    public String getLastName()
    {
        return surname; // return username username which was input
    }  
    
    public void setGender(String gndr)
    {
        gender = gndr; //assigning variables
    }
    
    public String getGender()
    {
        return gender; // return username username which was input
    } 
    
    public void setAge(int a)
    {
        age = a; //assigning variables
    }
    
    public int getAge()
    {
        return age; // return username username which was input
    }
}

