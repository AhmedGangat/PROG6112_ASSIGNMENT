
package Question2;
import javax.swing.*;
/**
 *
 * @author Ahmed
 */
public class Main {
     
    
    // variable declaration
    public static Doctor currentDoctor;
    public static boolean loggedIn = false;
    
    public static void main(String[] args) throws NoSuchMethodException  
    {  
        Login l = new Login();
        // check if user would like to login
        String menu = JOptionPane.showInputDialog(null,"Please Enter:\n1. Login\n2. Signup\n3. Exit");
        
        while(!menu.equals("3") && loggedIn == false)
        {
            switch (menu)
            {
                case "1":
                    System.out.println(l.returnLoginStatus());// creating new object l from login class
                    break;
                case "2": // allow user to login, after confirming user
                    l.getDetails();
                    System.out.println(l.registerUser());
                    break;
                case "3": // exit
                    System.exit(0);
            }
            
            menu = JOptionPane.showInputDialog("Please Enter:\n1. Login\n2. Signup\n3. Exit");
        }

        
    } 
}
