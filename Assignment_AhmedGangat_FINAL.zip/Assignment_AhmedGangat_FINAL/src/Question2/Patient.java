
package Question2;

import java.util.Vector;
import javax.swing.*;


 class Patient extends Person {
    
    Vector<Patient> IllnessHistory = new Vector<Patient>();  // new vector
    
    String illness; // variable
    public static Vector<String> doctorID = new Vector<String>(); // new vector
   // String id = name.substring(0,3) + ((Math.random() * (100 - 1)) + 1); 
    
    
  public Patient(String name,String surname, String gender, int age,String ill) // creating patient object
  {      
    super(name, surname, gender, age);
    illness = ill; 
  }
  
  public String getIllness()
  {
    return illness;
  }
  
  public static void setDoctorID(String drID)
  {
    doctorID.add(drID);
  }
   
}
