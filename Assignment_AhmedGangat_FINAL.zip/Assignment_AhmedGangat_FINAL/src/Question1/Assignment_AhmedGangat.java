/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Question1;
//ref - w3schools
//    - Stack Overflow
/**
 *
 * @author Ahmed
 */
public class Assignment_AhmedGangat {

   
    public static void main(String[] args) {
        Menu m = new Menu();
        
        
      m.displayMenu(); //calls displaymenu method from products class
    }
    }
    

