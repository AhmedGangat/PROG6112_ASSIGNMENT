/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question1;

/**
 *
 * @author Ahmed
 */
public class Student {
    



    //Variables
    public static String studentId;
    public static String studentName;
    public static int studentAge;
    public static String studentEmail;
    public static String studentCourse;

    //public static Products productsArray[] = new Products[5]
    public static int studentCount = 0;
    
    // creating an object
    public Student(String sId, String sName,int sAge,String sEmail, String sCourse)
    {
      studentId = sId ;
      studentName = sName ;
      studentAge = sAge;
      studentEmail = sEmail ;
      studentCourse = sCourse;
             
    }
    
    // Getter methods
    public String getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    // Setter methods
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentAge(int studentAge) {
        this.studentAge = studentAge;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public void setStudentCourse(String studentCourse) {
        this.studentCourse = studentCourse;
    }
}





