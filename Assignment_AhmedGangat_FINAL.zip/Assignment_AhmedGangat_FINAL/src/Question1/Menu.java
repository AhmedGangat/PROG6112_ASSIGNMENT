/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Question1;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Ahmed
 */
public class Menu 
{
    public static Scanner sc;
    public static int userInput;
    public static int start = -1;
    public static ArrayList<Student> studentList = new ArrayList<>();
    
  
     // method to create a display menu
    public static void displayMenu ()
    {
       
       System.out.println("STUDENT MANAGEMENT APPLICATION");
       System.out.println("****************");
       sc = new Scanner(System.in);
       
       if(start == -1)
       {
         System.out.println("Enter (1) to launch menu or any other key to exit");
         start = sc.nextInt();  
       }
       
       else if (start != 1)
        {
          ExitApplication();
        }
        userSelection(start);
     }     
     
    // method to allow user to select an option
    public static void userSelection(int userInput)
     {        
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit application.");
       
        userInput = sc.nextInt(); 
         switch(userInput) //switch statement
        {
            case 1: // Capture new student
                
                captureStudent();
               
                break;
            case 2: // Search for a new student
                System.out.println("Please enter the Student ID to search: ");
                int position1 = searchStudent(sc.next());
                
                if(position1 != -1)
                {
                    print(studentList.get(position1));
                    System.out.println("");
                    displayMenu();
                }
                else
                {
                    System.out.println("This student does not exist");
                    System.out.println("");
                    displayMenu();
                }
                break;
           
            case 3: // Delete a student
                System.out.println("Please enter the student code to search: ");
    String studentIdToDelete = sc.next();
    int positionToDelete = searchStudent(studentIdToDelete);

    if (positionToDelete != -1) {
        System.out.println("Are you sure you want to delete this student? (yes/no)");
        String confirmation = sc.next().toLowerCase();

        if (confirmation.equals("yes")) {
            deleteStudent(positionToDelete);
            System.out.println("Student deleted.");
        } else {
            System.out.println("Deletion canceled.");
        }
    } else {
        System.out.println("Student not found.");
    }

    displayMenu();
           case 4: // print report
                viewStudentReport();
    displayMenu();
                break;
            case 5: // exit Application
                ExitApplication();
                break; 
        }
         
     }  
         
         
    public static void captureStudent() //method which capures user input 
    {   
      System.out.println("Please enter the student id: ");
      String sId =sc.next();
      System.out.println("Please enter the student name: ");
      String sName= sc.next();
      int sAge;
        while (true) {
            System.out.println("Please enter the student age (must be >= 16):");
            
            if (sc.hasNextInt()) {
                sAge = sc.nextInt();
                if (sAge >= 16) {
                    break; // Valid age, exit the loop
                } else {
                    System.out.println("Invalid age. Age must be >= 16. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid number for age.");
                sc.next(); // Consume the invalid input
            }
        }     
      
      System.out.println("Please enter the Student email: ");
      String sEmail = sc.next();
      System.out.println("Please enter the student course ");
      String sCourse = sc.next();
      
      
      Student s = new Student(sId,sName,sAge,sEmail,sCourse);
      studentList.add(s);
      
      print(s);
      System.out.println("The student has been saved");
      System.out.println("");
      displayMenu();
    }
    
    public static int searchStudent(String studentId) {
    int pos = -1;

    for (int i = 0; i < studentList.size(); i++) {
        Student s = studentList.get(i);
        if (s.getStudentId().equals(studentId)) {
            pos = i;
            break; 
        }
    }
    return pos;
}

     public static void deleteStudent(int position) //accesses the list and deletes according to user input
  {
     studentList.remove(position);      
     displayMenu();
  }
    
    
    
       public static void print(Student s)
    {
        System.out.println("Student ID: " + s.getStudentId());
        System.out.println("Student Name: " + s.getStudentName());
        System.out.println("Student Age: " + s.getStudentAge());
        System.out.println("Student Email: " + s.getStudentEmail());
        System.out.println("Student Course: " + s.getStudentCourse());       
    }
    
    
    


// Define a method to generate and print the student report
public static void viewStudentReport() {
    System.out.println("Student Report:");

    int studentNumber = 1; // Initialize the student number

    for (Student student : studentList) {
        System.out.println("______________________________");
        System.out.println("Student " + studentNumber);
        System.out.println("______________________________");
        System.out.println("Student ID: " + student.getStudentId());
        System.out.println("Student Name: " + student.getStudentName());
        System.out.println("Student Age: " + student.getStudentAge());
        System.out.println("Student Email: " + student.getStudentEmail());
        System.out.println("Student Course: " + student.getStudentCourse());
        System.out.println();
        
        studentNumber++; // Increment the student number for the next student
    }
}


    
    
    
    
    
    
    
    
    
    
    
    
    
    
     public static void ExitApplication() // this methods quits the application
  {
    System.out.println("THANK YOU. GOODBYE !");
    System.exit(0);
  }
     
}

