/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Question2;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class MainTest {

    private Login login;

    @Before
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testReturnLoginStatusSuccessfulLogin() throws NoSuchMethodException {
        // Assuming valid login details are provided
        login.userName = "ah_m";
        login.passWord = "gangat123";

        // Attempt to log in and capture the login status
        String loginStatus = login.returnLoginStatus();

        // Check if the login status indicates a successful login
        assertTrue(loginStatus.contains("Welcome"));
    }

    @Test
    public void testReturnLoginStatusFailedLogin() throws NoSuchMethodException {
        // Assuming invalid login details are provided
        login.userName = "invalid_username";
        login.passWord = "invalid_password";

        // Attempt to log in and capture the login status
        String loginStatus = login.returnLoginStatus();

        // Check if the login status indicates a failed login
        assertTrue(loginStatus.contains("Username or password incorrect"));
    }

    // You can add more tests for other behaviors of the Main class as needed

}
