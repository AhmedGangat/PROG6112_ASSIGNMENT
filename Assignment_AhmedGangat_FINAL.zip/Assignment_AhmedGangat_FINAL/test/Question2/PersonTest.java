/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Question2;

import static org.junit.Assert.*;
import org.junit.Test;

public class PersonTest {

    @Test
    public void testConstructorAndGetters() {
        Person person = new Person("John", "Doe", "Male", 30);
        
        // Check if the constructor initializes the fields correctly
        assertEquals("John", person.getFirstName());
        assertEquals("Doe", person.getLastName());
        assertEquals("Male", person.getGender());
        assertEquals(30, person.getAge());
    }

    @Test
    public void testSetters() {
        Person person = new Person("John", "Doe", "Male", 30);
        
        // Update the fields using setter methods
        person.setFirstName("Alice");
        person.setLastName("Smith");
        person.setGender("Female");
        person.setAge(25);
        
        // Check if the setter methods update the fields correctly
        assertEquals("Alice", person.getFirstName());
        assertEquals("Smith", person.getLastName());
        assertEquals("Female", person.getGender());
        assertEquals(25, person.getAge());
    }

    // Additional tests for other Person class functionalities can be added here

}
