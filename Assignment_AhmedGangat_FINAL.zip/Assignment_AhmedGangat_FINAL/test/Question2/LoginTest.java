/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Question2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    private Login login;

    @Before
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testCheckUserNameValid() {
        login.username = "ah_m";
        assertTrue(login.checkUserName());
    }

    @Test
    public void testCheckUserNameInvalid() {
        login.username = "username"; // Invalid because it lacks an underscore and is longer than 5 characters
        assertFalse(login.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexityValid() {
        login.password = "Gangat123"; // Meets password complexity requirements
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {
        login.password = "simple"; // Invalid because it's too short
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testLoginUserValid() {
        // Assuming you have added a Doctor with username "ah_m" and password "gangat123" to doctorVector
        login.doctorVector.add(new Doctor("ah_m", "gangat123", "SomeDepartment", "John", "Doe", "Male", 30));
        login.username = "ah_m";
        login.password = "gangat123";
        assertTrue(login.LoginUser());
    }

    @Test
    public void testLoginUserInvalid() {
        // Assuming you have added a Doctor with username "ah_m" and password "gangat123" to doctorVector
        login.doctorVector.add(new Doctor("ah_m", "gangat123", "SomeDepartment", "John", "Doe", "Male", 30));
        login.username = "ah_m";
        login.password = "wrongpassword"; // Incorrect password
        assertFalse(login.LoginUser());
    }
}
