/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Question1;

import static Question1.Menu.sc;
import static Question1.Menu.studentList;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ahmed
 */
public class MenuTest {
    
   
    @Test
public void testCaptureStudent() {
//  
    String studentId = "bob002" ; 
    String studentName = "Bob";
    int studentAge = 18;
    String studentEmail = "bob1@gmail.com";
    String studentCourse = "BCAD";
      
   Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
    // Call the method you want to test
   
    
    // Assert or check the output and any expected results
    String expectedOutput = "Please enter the student id:\nPlease enter the student name:\nPlease enter the student age (must be >= 16):\nPlease enter the Student email:\nPlease enter the student course\nStudent ID: 123\nStudent Name: John\nStudent Age: 18\nStudent Email: john@example.com\nStudent Course: Math\nThe student has been saved\n\n";
    assertEquals("bob002", student.getStudentId());
    assertEquals("Bob", student.getStudentName());
    assertEquals(18, student.getStudentAge());
    assertEquals("bob1@gmail.com", student.getStudentEmail());
    assertEquals("BCAD", student.getStudentCourse());
}
@Test
public void testsearchStudent(){
     
    String studentId = "bob002" ; 
    String studentName = "Bob";
    int studentAge = 18;
    String studentEmail = "bob1@gmail.com";
    String studentCourse = "BCAD";
      
   Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
   int pos = -1;
   
   for (int i = 0; i < studentList.size(); i++)
   {
       if (student.getStudentId().equals(studentId)) {
            pos = i;
            
    assertEquals("bob002", student.getStudentId());
   
   
}

}
   
}
 @Test
public void testDeleteStudent() {
    // Assuming you have a student at position 0 in studentList to delete
    int positionToDelete = 0;

    // Create a student for testing purposes and add it to studentList
    String studentId = "test123";
    String studentName = "Test Student";
    int studentAge = 20;
    String studentEmail = "test@student.com";
    String studentCourse = "Test Course";
    Student testStudent = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
    studentList.add(testStudent);

    // Capture the size of the list before deletion
    int initialSize = studentList.size();

    // Call the deleteStudent method to delete the student at the specified position
    Menu.deleteStudent(positionToDelete);

    // Check if the student has been removed from the list
    assertEquals(initialSize - 1, studentList.size());

    // Ensure that the deleted student is no longer in the list
    assertFalse(studentList.contains(testStudent));
}

    @Test
    public void testPrint() {
        String studentId = "bob002";
        String studentName = "Bob";
        int studentAge = 18;
        String studentEmail = "bob1@gmail.com";
        String studentCourse = "BCAD";
        
        Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        
        // Redirect System.out to capture the output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        
        // Call the print method with the student object
        Menu.print(student);
        
        // Restore the standard output
        System.setOut(System.out);
        
        // Check if the output matches the expected format
        String expectedOutput = "Student ID: bob002\n" +
                               "Student Name: Bob\n" +
                               "Student Age: 18\n" +
                               "Student Email: bob1@gmail.com\n" +
                               "Student Course: BCAD\n";
        assertEquals(expectedOutput, outContent.toString());
}
     @Test
    public void testViewStudentReport() {
        // Assuming studentList contains some students
        
        // Redirect System.out to capture the output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        
        // Call the viewStudentReport method
        Menu.viewStudentReport();
        
        // Restore the standard output
        System.setOut(System.out);
        
        // Check if the output contains "Student Report:" which indicates the report is displayed
        assertTrue(outContent.toString().contains("Student Report:"));
    }
     @Test
    public void testExitApplication() {
        // This method doesn't return anything or have a direct output to test,
        // but you can check if it terminates the application successfully.
        // If it terminates without any exceptions, the test passes.
    }
 
 @Test
    public void testStudentAge() {
        // Create a student object with an age
        String studentId = "test123";
        String studentName = "Test Student";
        int studentAge = 20; // Set the age to 20 for testing
        String studentEmail = "test@student.com";
        String studentCourse = "Test Course";
        Student testStudent = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);

        // Check if the getStudentAge() method returns the correct age
        assertEquals(20, testStudent.getStudentAge());

        // Update the age using setStudentAge() method
        testStudent.setStudentAge(25);

        // Check if the updated age is reflected
        assertEquals(25, testStudent.getStudentAge());
    }
}


